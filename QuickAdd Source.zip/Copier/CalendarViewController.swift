//
//  CalendarViewController.swift
//  Copier
//
//  Created by Will Bishop on 18/8/18.
//  Copyright © 2018 Will Bishop. All rights reserved.
//

import Cocoa
import SwiftyChrono
import EventKit

class CalendarViewController: NSViewController {

    @IBOutlet weak var eventInputField: NSTextField!
    let chrono = Chrono()
    let eventStore = EKEventStore()

    override func viewDidLoad() {
        super.viewDidLoad()
        // 1
        // 2
        eventStore.requestAccess(to: EKEntityType.event, completion: {result, error  in
           
        })
        // Do view setup here.
    }
    @IBAction func parseInput(_ sender: Any) {
        let fullEntry = eventInputField.stringValue
        let result = chrono.parse(text: fullEntry)
        if let time = result.first{
            let timeAsText = time.text
            let event = fullEntry.replacingOccurrences(of: timeAsText, with: "")
            let date = time.start.date
            let endDate = time.end?.date ?? date.addingTimeInterval(60*60)
            
            print("Event: \(event)\n Time: \(date)")
            self.insertEvent(eventName: event, startDate: date, endDate: endDate)
        } else {
            let error = NSError(domain:"", code:401, userInfo:[ NSLocalizedDescriptionKey: "Couldn't find a time"])
            self.presentError(error)
        }
    }
    
    @IBAction func shouldQuit(_ sender: Any) {
        NSApplication.shared.terminate(self)
    }
    func insertEvent(eventName: String, startDate: Date, endDate: Date){
        guard let calendar = eventStore.defaultCalendarForNewEvents else {
            return
        }
        let currentCalender = Calendar.current
        let now = Date()
        let noonToday = currentCalender.date(bySetting: .hour, value: 12, of: now)!
        var startDate = startDate
        var endDate = endDate
        if now < noonToday{ //It's noon
            startDate = startDate.addingTimeInterval(60*60*12)
            endDate = endDate.addingTimeInterval(60*60*12)

        }
        
      
        var event = EKEvent(eventStore: eventStore)
        event.title = eventName
        event.startDate = startDate
        event.endDate = endDate
        event.addAlarm(EKAlarm(relativeOffset: -60))
        var error: NSError?
        do {
            event.calendar = calendar
            let result = try eventStore.save(event, span: EKSpan.thisEvent, commit: true)
            
        } catch{
            self.presentError(error)
        }
        if let delegate = NSApplication.shared.delegate as? AppDelegate{
            delegate.closePopover(sender: self)
        }
    }
    
}

extension CalendarViewController {
    // MARK: Storyboard instantiation
    static func freshController() -> CalendarViewController {
        //1.
        let storyboard = NSStoryboard(name: NSStoryboard.Name(rawValue: "Main"), bundle: nil)
        //2.
        let identifier = NSStoryboard.SceneIdentifier(rawValue: "CalendarViewController")
        //3.
        guard let viewcontroller = storyboard.instantiateController(withIdentifier: identifier) as? CalendarViewController else {
            fatalError("Why cant i find CalendarViewController? - Check Main.storyboard")
        }
        return viewcontroller
    }
}
