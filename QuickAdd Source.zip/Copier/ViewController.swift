//
//  ViewController.swift
//  Copier
//
//  Created by Will Bishop on 16/8/18.
//  Copyright © 2018 Will Bishop. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

